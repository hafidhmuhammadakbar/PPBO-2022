// Nama : Hafidh Muhammad Akbar
// NIM  : M0521026

public class Dummy {
    public static void main(String[] args) {
        System.out.println("Hallo World!");
    }
}